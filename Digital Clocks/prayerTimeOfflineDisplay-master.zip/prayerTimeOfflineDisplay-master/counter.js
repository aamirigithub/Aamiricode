var end = 0         // change this to stop the counter at a higher value
var refresh=1000;   // Refresh rate in milli seconds

function display_c(start){
window.start = parseFloat(start);

if(window.start >= end ){
mytime=setTimeout('display_ct()',refresh)
}
//else {alert("Time is up! ");}
else {
    new Audio('allah_o_akbar.mp3').play();   
    }
}

function display_ct() {
// Calculate the number of days left
var days=Math.floor(window.start / 86400);

// After deducting the days calculate the number of hours left
var hours = Math.floor((window.start - (days * 86400 ))/3600);

// After days and hours , how many minutes are left 
var minutes = Math.floor((window.start - (days * 86400 ) - (hours *3600 ))/60);

// Finally how many seconds left after removing days, hours and minutes. 
var secs = Math.floor((window.start - (days * 86400 ) - (hours *3600 ) - (minutes*60)));

//var x = + hours + " HOURS "  + minutes + " MINTS & "  + secs + " SEC ";
//document.getElementById('ct').innerHTML = x;

//document.getElementById('ct-days').innerHTML = days;
document.getElementById('ct-hours').innerHTML = hours + ":";
document.getElementById('ct-minutes').innerHTML = minutes + ":";
document.getElementById('ct-secs').innerHTML = secs;

window.start= window.start- 1;

tt=display_c(window.start);
}
