<?php
$servername = "localhost";
$username = "aamir";
$password = "Cerner@1995";
$dbname = "prayers";
$datenow = date("Y/m/d");

$a_date;

$a_player_1;
$a_start_time_1;
$a_end_time_1;

$a_player_2;
$a_start_time_2;
$a_end_time_2;

$a_player_3;
$a_start_time_3;
$a_end_time_3;

$a_player_4;
$a_start_time_4;
$a_end_time_4;

$a_player_5;
$a_start_time_5;
$a_end_time_5;

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//$sql = "SELECT date, player_1, start_time_1, end_time_1 FROM playersTime";
$sql = "SELECT * FROM `prayersTime` WHERE date='$datenow'";

$result = $conn->query($sql);
//echo "Todays's date is: $datenow <br>";

if ($result->num_rows > 0) {

    // output data of each row
    while($row = $result->fetch_assoc()) {

    $a_date = 		            $row["date"];

	$a_player_1 = 		        $row["prayer_1"];
	$a_start_time_1 = 	        $row["start_time_1"];
    $a_end_time_1 = 	        $row["end_time_1"];
    
    $a_sunrise =                 $row["sunrise"];

	$a_player_2 = 		        $row["prayer_2"];
	$a_start_time_2 =	        $row["start_time_2"];
	$a_end_time_2 =		        $row["end_time_2"];

	$a_player_3 =               $row["prayer_3"];
    $a_start_time_3 =           $row["start_time_3"];
    $a_end_time_3 =             $row["end_time_3"];

	$a_player_4 =               $row["prayer_4"];
    $a_start_time_4 =           $row["start_time_4"];
    $a_end_time_4 =             $row["end_time_4"];

	$a_player_5 =               $row["prayer_5"];
    $a_start_time_5 =           $row["start_time_5"];
    $a_end_time_5 =             $row["end_time_5"];

    //Test Data direclt from DB
	// echo $row["player_1"];
	// echo $row["start_time_1"];
	// echo $row["end_time_1"];
    // echo $row["player_2"];
    
    // Test Data from variables of DB
    // echo "<br> $a_date";
	// echo "<br> $a_player_1";
	// echo "<br> $a_start_time_1";
    // echo "<br> $a_end_time_1";

    // // Convert 24 hours to 12 hours AM/PM format
    // echo date('h:i:s a', strtotime($a_end_time_1));
    
    }

} else {
    echo "0 results from playersDB_a";
}

$conn->close();
?>
