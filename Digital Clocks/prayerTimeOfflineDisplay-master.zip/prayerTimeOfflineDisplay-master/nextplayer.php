<?php

include("playersDB_a.php");
// $page = $_SERVER['PHP_SELF'];
// $sec = "15";
// header("Refresh: $sec");

$timenow = strtotime('now');		// Current time in seconds


// Data coming from playersDB_a.php
    $a_player_1;
    $np_start_time_1 =  strtotime($a_start_time_1);
    $np_end_time_1 =  strtotime($a_end_time_1);

    $a_player_2;
	$np_start_time_2 = strtotime($a_start_time_2);
	$np_end_time_2 = strtotime($a_end_time_2);

	$a_player_3;
    $np_start_time_3 = strtotime($a_start_time_3);
    $np_end_time_3 = strtotime($a_end_time_3);

	$a_player_4;
    $np_start_time_4 = strtotime($a_start_time_4);
    $np_end_time_4 = strtotime($a_end_time_4);

	$a_player_5;
    $np_start_time_5 = strtotime($a_start_time_5);
	$np_end_time_5 = strtotime($a_end_time_5);
	
	// Next day data
	include("playersDB_b.php");
	$b_date;
	$b_player_1;
    $nextday_start_time_1 = strtotime($b_start_time_1);
	$nextday_end_time_1 = strtotime($b_end_time_1);
	$currentime = date('H:i:s', time());
	$currentday = date("l");
	
	$today_datetime="$a_date $currentime"; 
	$tomorrow_datetime="$b_date $b_end_time_1"; 
	
	$startdate="$a_date $currentime"; 
	$enddate="$b_date $b_end_time_1"; 
	// echo "<br> $startdate";
	// echo "<br> $enddate";
	// 	$diff=strtotime($enddate)-strtotime($startdate); 
	// 	echo "<br> diff in seconds: $diff";

// Next prayer and countdown will trigger after between Azan and Iqamah time
if ($timenow < $np_end_time_1 ){
	$nextplayer = $a_player_1;
	$countdowntime = $np_end_time_1 - $timenow;
	$iqama_next = $np_end_time_1;
	// echo "<br> ---player: $nextplayer";
	// echo "<br> ---countdown: $countdowntime";
}

elseif ($timenow < $np_end_time_2 ){
		if ($currentday == "Friday" ){
			$nextplayer = "Jummah";	
			$countdowntime = strtotime('13:35:00') - $timenow;
		} else {
			$nextplayer = $a_player_2;
			$countdowntime = $np_end_time_2 - $timenow;	
		}

	//$nextplayer = $a_player_2;
	//$countdowntime = $np_end_time_2 - $timenow;
	$iqama_next = $np_end_time_2;
	// echo "<br> ---player: $nextplayer";
	// echo "<br> ---countdown: $countdowntime";

}
	
elseif ($timenow < $np_end_time_3 ){
	$nextplayer = $a_player_3;
	$countdowntime = $np_end_time_3 - $timenow;
	$iqama_next = $np_end_time_3;
	// echo "<br> ---player: $nextplayer";
	// echo "<br> ---countdown: $countdowntime";
}

elseif ($timenow < $np_end_time_4 ){
	$nextplayer = $a_player_4;
	$countdowntime = $np_end_time_4 - $timenow;
	$iqama_next = $np_end_time_4;
	// echo "<br> ---player: $nextplayer";
	// echo "<br> ---countdown: $countdowntime";
}

elseif ($timenow < $np_end_time_5 ){
	$nextplayer = $a_player_5;
	$countdowntime = $np_end_time_5 - $timenow;
	$iqama_next = $np_end_time_1;
	// echo "<br> ---player: $nextplayer";
	// echo "<br> ---countdown: $countdowntime";
}
	
elseif ($timenow >  $np_end_time_5 ){
	$nextplayer = $b_player_1;
	//$countdowntime = $nextday_end_time_1 - $currentime;
	$countdowntime = strtotime($tomorrow_datetime) - strtotime($today_datetime);
	$iqama_next = $np_end_time_5;
	// echo "<br> ---player: $nextplayer";
	// echo "<br> ---countdown: $countdowntime";
}

//echo $nextplayer;
//echo $countdowntime;


// echo "<br> ---player: $nextplayer";
// echo "<br> ---countdown: $countdowntime";

//sleep($countdowntime);

//echo date('Y-m-d H:i:s', strtotime("+1 days"));

// $startdate="2019-08-23 24:00:00"; 
// $enddate="2019-08-24 05:00:00"; 

// $diff=strtotime($enddate)-strtotime($startdate); 
// echo "<br> diff in seconds: $diff"; // Divide answer with 3600 for getting hours

$page = $_SERVER['PHP_SELF'];
$sec = 140;
header("Refresh: $sec");


?>
