<!DOCTYPE html>
<html lang="en">
<title>ICNKC Prayer Setup</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<script>
function w3_open() {
    document.getElementById("mySidebar").style.display = "block";
}
function w3_close() {
    document.getElementById("mySidebar").style.display = "none";
}
</script>

<body>

<!-- Side navigation bar starts here -->
<nav class="w3-sidebar w3-bar-block w3-teal w3-card w3-large" style="display:none" id="mySidebar">
  <a href="javascript:void(0)" onclick="w3_close()" 
  class="w3-button w3-teal w3-right">&times;</a><br>
  <a class="w3-bar-item w3-button" href="#iqama">Iqama Setup</a>
  <a class="w3-bar-item w3-button" href="#year">Year Setup</a>
  <a class="w3-bar-item w3-button" href="#time">Time Setup</a>
  <a class="w3-bar-item w3-button" href="#daylight">Daylight Setup</a>
</nav>

<!-- Header starts here -->
<header class="w3-light-grey">
  <button class="w3-button w3-light-grey w3-xxlarge" onclick="w3_open()">&#9776;</button>
  <div class="w3-container">
  </div>
</header>

<!-- Main body contents starts here -->
<div class="w3-container" id="iqama"> 
  <div class="w3-card-4">
    <div class="w3-container w3-light-green">
      <h2>IQAMA SETUP OFFLINE</h2>
    </div>
    <form method="post" action="" class="w3-container">
        <p>Enter iqama time in minutes</p>
        <input type="number" placeholder="Input Fajar Iqama" name="new_fajar_iqama" class="w3-input w3-border w3-round-xxlarge"><br/>
        <input type="number" placeholder="Input Zuhr Iqama" name="new_zuhr_iqama" class="w3-input w3-border w3-round-xxlarge"><br/>
        <input type="number" placeholder="Input Asr Iqama" name="new_asr_iqama" class="w3-input w3-border w3-round-xxlarge"><br/>
        <input type="number" placeholder="Input Maghrib Iqama" name="new_maghrib_iqama" class="w3-input w3-border w3-round-xxlarge"><br/>
        <input type="number" placeholder="Input Isha Iqama" name="new_isha_iqama" class="w3-input w3-border w3-round-xxlarge"><br/>
        <input type="number" placeholder="Daylight Saving (1 or -1)" min="-1" max="1" name="new_daylight_saving" class="w3-input w3-border w3-round-xxlarge"><br/>
        <input type="submit" name="submit" value="submit" class="w3-btn w3-round w3-teal w3-border w3-hover-green">
    </form>

  </div>
</div>
<!-- Contents ends here-->

<!-- Footer starts here -->
  <footer class="w3-container w3-bottom w3-light-green w3-theme w3-margin-top">
  <h5>For any issue, send email to aamiriweb@gmail.com</h5>
</footer>
<!-- Footer ends here -->

<!-- PHP Start here -->

<?php
$servername = "localhost";
$username = "aamir";
$password = "Cerner@1995";
$dbname = "prayers";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$fajar_iqama = $_POST[new_fajar_iqama];
echo "<span>FAJAR IQAMA =  <b>" . $fajar_iqama . "</b>.</span>";

$zuhr_iqama = $_POST[new_zuhr_iqama];
echo "<span>ZUHR IQAMA =  <b>" . $zuhr_iqama . "</b>.</span>";

$asr_iqama = $_POST[new_asr_iqama];
echo "<span>ASR IQAMA =  <b>" . $asr_iqama . "</b>.</span>";

$maghrib_iqama = $_POST[new_maghrib_iqama];
echo "<span>MAGRIB IQAMA =  <b>" . $maghrib_iqama . "</b>.</span>";

$isha_iqama = $_POST[new_isha_iqama];
echo "<span>ISHA IQAMA =  <b>" . $isha_iqama . "</b>.</span>";

$daylight_saving = $_POST[new_daylight_saving];
echo "<span>DAYLIGHT SAVING =  <b>" . $daylight_saving . "</b>.</span>";
print "                   ";

$sql1 = "CALL FAJAR($fajar_iqama);";
$res1 =mysqli_query($conn,$sql1);

$sql2 = "CALL ZUHR($zuhr_iqama);";
$res2 =mysqli_query($conn,$sql2);

$sql3 = "CALL ASR($asr_iqama);";
$res3 =mysqli_query($conn,$sql3);

$sql4 = "CALL MAGHRIB($maghrib_iqama);";
$res4 =mysqli_query($conn,$sql4);

$sql5 = "CALL ISHA($isha_iqama);";
$res5 =mysqli_query($conn,$sql5);

$sql6 = "CALL DAYLIGHT($daylight_saving);";
$res6 =mysqli_query($conn,$sql6);

//$sql = "CALL ZUHR(20);";
//$result = $conn->query($sql);
$conn->close();

?>
<!-- PHP ends here -->

</body>
</html>
