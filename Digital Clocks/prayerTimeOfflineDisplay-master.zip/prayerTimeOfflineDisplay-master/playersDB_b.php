<?php
$servername = "localhost";
$username = "aamir";
$password = "Cerner@1995";
$dbname = "prayers";
$datenow = date("Y/m/d");
$datetomorrow = date('Y/m/d', strtotime("+1 days"));

$b_date;
$b_player_1;
$b_start_time_1;
$b_end_time_1;

$b_player_2;
$b_start_time_2;
$b_end_time_2;

$b_player_3;
$b_start_time_3;
$b_end_time_3;

$b_player_4;
$b_start_time_4;
$b_end_time_4;

$b_player_5;
$b_start_time_5;
$b_end_time_5;

// Create connection
$conn_b = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn_b->connect_error) {
    die("Connection failed: " . $conn_b->connect_error);
}

//$sql = "SELECT date, player_1, start_time_1, end_time_1 FROM playersTime";
//$sql_b = "SELECT * FROM `playersTime` WHERE date='$datenow'";
$sql_b = "SELECT * FROM `prayersTime` WHERE date='$datetomorrow'";

$result = $conn_b->query($sql_b);
//echo "Todays's date is: $datenow <br>";

if ($result->num_rows > 0) {

    // output data of each row
    while($row = $result->fetch_assoc()) {

    $b_date = 		            $row["date"];

	$b_player_1 = 		        $row["prayer_1"];
	$b_start_time_1 = 	        $row["start_time_1"];
	$b_end_time_1 = 	        $row["end_time_1"];

	$b_player_2 = 		        $row["prayer_2"];
	$b_start_time_2 =	        $row["start_time_2"];
	$b_end_time_2 =		        $row["end_time_2"];

	$b_player_3 =               $row["prayer_3"];
    $b_start_time_3 =           $row["start_time_3"];
    $b_end_time_3 =             $row["end_time_3"];

	$b_player_4 =               $row["prayer_4"];
    $b_start_time_4 =           $row["start_time_4"];
    $b_end_time_4 =             $row["end_time_4"];

	$b_player_5 =               $row["prayer_5"];
    $b_start_time_5 =           $row["start_time_5"];
    $b_end_time_5 =             $row["end_time_5"];

    // Testing DB database
    // echo $row["player_1"];
	// echo $row["start_time_1"];
	// echo $row["end_time_1"];
    // echo $row["player_2"];
    
    //Testing DB data varibales
    // echo "<br> $b_date";
    // echo "<br> $b_player_1";
    // echo "<br> $b_start_time_1";
    // echo "<br> $b_end_time_1";

    }

} else {
    echo "0 record from DB_b";
}

$conn_b->close();
?>
