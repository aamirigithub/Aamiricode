<!DOCTYPE html>
<html>
<title>Players</title>
<head>
<meta http-equiv="refresh" content="5">  
    <meta name="google" content="notranslate">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="w3.css">
    <link rel="stylesheet" href="style.css">
    <script src="counter.js"></script>
    
</head>
<style style="text/css">

@font-face {
            font-family: 'digital-7';
            src: url('digital-7.ttf');
            }
        .newfont {
            font-family: 'digital-7';
            }

/* top left DIV for silence the phone*/
.phone_silence {
  position: relative;
  left: 0;
  top: 0;
  width: 36.5vw;
  height: 10vh;

  font-size: 2.8vw;
  font-weight: bold;
  text-align: center;
  
}

/* top right DIV for english date*/
.date_header {    
  position: relative;
  left: 0;
  top: 0;
  width: 60vw;
  height: 10vh;
  text-align: center;
  font-size: 3vw;
}
.date_span{
    color: grey;
    font-size: 3.3vw;
    font-weight: bold;
    text-shadow:5px 5px 5px #ABB;
}

/* Adjust the middle left DIV */
.middlebox {
    position: relative;
    margin-top: 0.5%;    
    width: 100vw; /* Adjust Blue box width of time table*/
    height: 74vh;
    padding: 0.5%;
}

/* Adjust the middle right DIV*/
.nextbox{
    position: relative;
    margin-top: 0%;
    margin-left: 0%;    
    width: 50vw;
    height: 74vh;
    padding: 0.5%;
}
.timeTableBox{
    position: relative;
    margin-top: 3%;    
    width: 45vw;
    height: 72vh; /* Adjust the table height with middle box height*/
    padding: 0.1%;
}
tr{
    width:8vw;
    font-size: 1.9vw;
    text-align: center;
    font-weight: bold;
}

/* Adjust properties of NEXT... and NEXT IQAMA*/
.p_next{
    width:60vw;
    font-size: 4vw;         /* Adjust this value for bigger screen tv*/
    text-align: center;
    font-weight: bold;
}

.counter{
    width:80%;
    font-size: 200%;        /* Adjust the size of counter digits 100% for laptop & 550% for 43 inch tv*/
    color: brown;
    text-align: center;
    font-weight: bold;
    margin-left: 1%;
}

/* Footer lane starts from here*/
.clock_footer {
  position: relative;
  display: inline-block;
  left: 0;
  bottom: -10px;                /* -10px for laptop and -40px for 43 inch tv*/
  width: 38vw;
  height: 10vh;
  
  text-align: center;
  font-size: 3vw;
  

}
.text_scroller {
  position: relative;
  display: inline-block;
  left: 10;
  bottom: -10px;            /*distance from bottom( -10px for laptop and -40px for 43 inch tv) */
  width: 60.5vw;            /* Width of wrapping DIV */
  height: 10vh;             /* Height of wrapping DIV */
  margin: 0 auto;

  text-align: center;
  font-size: 2.5vw;         /* Font size of the text scroller*/
  font-weight: bold;
  /* Scroller properties handle by Marquee itself*/
  /* Margin-top in HTML P tag controls text alignment and not CSS */
}
.timeclock{
    width:40vw;
    font-size: 4vw;         /* 3vw for laptop and 4vw for 43 inch tv*/
    height: 10vh;
    text-align: center;
    font-weight: bold;
}

</style>
<script></script>
<body>
    <?php include("playersDB_a.php");?>

    <!--Two Column header starts from here -->
    <header class="w3-container">
        <!-- Column for Message -->
        <div class="phone_silence w3-third w3-round-xxlarge w3-green w3-center  w3-card-4">
        <blink>Silence Your Phone</blink></div>
        <!-- Column for Date -->
        <div class="date_header w3-twothird w3-container w3-round-xxlarge w3-center w3-border w3-light-grey w3-card-4" style="text-shadow:5px 5px 5px #4BB">
       <span class="date_span"><?php echo date('D jS, M Y', strtotime($datenow)); ?></span>
        </div>
    </header>
    <!-- Header section ends here -->

    <!-- Prayer time table start from here-->
    <div class="middlebox">
        <div class="w3-container w3-left w3-xlarge w3-round-large w3-blue w3-center  w3-card-4" style="width: 47vw">  

                <table class="timeTableBox w3-table w3-bordered" style="text-shadow:5px 1px 5px #444">
                    <tr class=" w3-black ">
                        <th>PRAYER</th>
                        <th>الصلاة</th>
                        <th>AZAAN</th>
                        <th>IQAMAH</th>
                    </tr>
                    <tr>
                        <td class="w3-black">FAJAR</td>
                        <td class="w3-grey w3-text-white">الفجر</td>
                        <td><?php echo date('h:i A', strtotime($a_start_time_1)) ?></td>
                        <td><?php echo date('h:i A', strtotime($a_end_time_1)) ?></td>
                    </tr>
                    <tr>
                        <td class="w3-black">SUNRISE</td>
                        <td class="w3-grey w3-text-white">الشروق</td>
                        <td><?php echo date('h:i A', strtotime($a_sunrise)) ?></td>
                        <td></td>
                    </tr>
                    <tr>
                        <td class="w3-black">ZUHR</td>
                        <td class="w3-grey w3-text-white">الظهر</td>
                        <td><?php echo date('h:i A', strtotime($a_start_time_2)) ?></td>
                        <td><?php echo date('h:i A', strtotime($a_end_time_2)) ?></td>
                    </tr>
                    <tr>
                        <td class="w3-black">ASR</td>
                        <td class="w3-grey w3-text-white">العصر</td>
                        <td><?php echo date('h:i A', strtotime($a_start_time_3)) ?></td>
                        <td><?php echo date('h:i A', strtotime($a_end_time_3)) ?></td>
                    </tr>
                    <tr>
                        <td class="w3-black">MAGHRIB</td>
                        <td class="w3-grey w3-text-white">المغرب</td>
                        <td><?php echo date('h:i A', strtotime($a_start_time_4)) ?></td>
                        <td><?php echo date('h:i A', strtotime($a_end_time_4)) ?></td>
                    </tr>
                    <tr>
                        <td class="w3-black">ISHA</td>
                        <td class="w3-grey w3-text-white"> العشاء</td>
                        <td><?php echo date('h:i A', strtotime($a_start_time_5)) ?></td>
                        <td><?php echo date('h:i A', strtotime($a_end_time_5)) ?></td>
                    </tr>
                    <tr>
                        <td class="w3-black">JUMMAH</td>
                        <td class="w3-grey w3-text-white">الجمعة</td>
                        <td>1:35 PM</td>
                        <td></td>
                    </tr>

                </table>
            

        </div>
            <!-- Center right column start here -->
        <div class="nextbox w3-twothird w3-container w3-left w3-light-grey w3-round-large w3-center w3-xxxlarge w3-card-4" style="text-shadow:5px 5px 5px #ABB">
                    <p class="p_next" style="color:grey">NEXT...</p>
                        <?php include("nextplayer.php");?>
                        <p class="p_next" style="color:grey"><?php echo $nextplayer; ?> Iqamah</p>
                        
                        <!-- This will be used for testing counter time
                        <p><?php echo $countdowntime; ?></p>
                        -->


                    <!-- Counter starts here -->
                    <script>onload=display_c(<?php echo $countdowntime; ?>);</script>
                    <div class="">
                        <span class='counter' id='ct-hours'></span>
                        <span class='counter' id='ct-minutes'></span>
                        <span class='counter' id='ct-secs'></span>
                    </div>
        </div>
    </div>
    <!-- Moving scroll message starts here-->
    <?php include("playersDB_b.php");?>
    <footer class="w3-container">
        <div class="timeclock clock_footer  w3-black w3-third w3-container  w3-round-large w3-center w3-round-xxlarge w3-lime  w3-card-4" style="text-shadow:1px 1px 1px #444"> 
            <div class="newfont" id="clock">Time</div>
            <script src="clock.js"></script>              
        </div>
        <!-- Bottom Moving Tomorrow Iqama Time-->
        <div class="text_scroller w3-twothird w3-container w3-border w3-round-xxlarge w3-white  w3-card-4" style="text-shadow:1px 1px 5px #444">
            <marquee behavior="scroll" direction="left" scrollamount="15" scrolldelay="100" width="100%" style="margin-top: 0px; color: lightgrey"><?php echo "IQAMA TOMORROW    " ?>&#8658;
            <b style="background-color:black">FAJAR</b><i style="color:brown"><?php echo date('h:i A', strtotime($b_end_time_1)) ?></i>
            <b style="background-color:black">ZUHR</b><i style="color:brown"><?php echo date('h:i A', strtotime($b_end_time_2)) ?></i>
            <b style="background-color:black">ASR</b><i style="color:brown"><?php echo date('h:i A', strtotime($b_end_time_3)) ?></i>
            <b style="background-color:black">MAGHRIB</b><i style="color:brown"><?php echo date('h:i A', strtotime($b_end_time_4)) ?></i>
            <b style="background-color:black">ISHA</b><i style="color:brown"><?php echo date('h:i A', strtotime($b_end_time_5)) ?></i>
            </marquee>
        </div>
    </footer>
    

</body>
</html>
